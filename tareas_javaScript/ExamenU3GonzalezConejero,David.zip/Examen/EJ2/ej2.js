function enviar() {
  let cadena = document.getElementById("texto").value;
  cadena = cadena.toUpperCase();
  alert(cadena);
  if (isNaN) {
  }
  let abecedario = [
    "a",
    "b",
    "c",
    "d",
    "e",
    "f",
    "g",
    "h",
    "i",
    "j",
    "k",
    "l",
    "n",
    "ñ",
    "o",
    "p",
    "q",
    "r",
    "s",
    "t",
    "u",
    "v",
    "w",
    "x",
    "y",
    "z",
  ];
}
